import static org.junit.Assert.*;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import cs3500.pyramidsolitaire.model.hw04.PyramidSolitaireCreator;
import cs3500.pyramidsolitaire.model.hw04.PyramidSolitaireCreator.GameType;
import org.junit.Test;

public class PyramidSolitaireCreatorTest {

  @Test
  public void create() {
    PyramidSolitaireModel<Card> p1;
    PyramidSolitaireCreator c1 = new PyramidSolitaireCreator();
    p1 = c1.create(GameType.BASIC);
    assertEquals(new BasicPyramidSolitaire().getClass(),p1.getClass());
  }
}