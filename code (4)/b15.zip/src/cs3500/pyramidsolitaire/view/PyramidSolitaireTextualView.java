package cs3500.pyramidsolitaire.view;

import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import java.io.IOException;

/**
 * represents the view for the game and renders the solitaire game.
 */
public class PyramidSolitaireTextualView implements PyramidSolitaireView {

  private final PyramidSolitaireModel<?> model;
  private Appendable ap;
  // ... any other fields you need

  /**
   * represents 2 argument constructor for the view.
   *
   * @param model represents the model for the pryamid solitaire game
   * @param ap    represents the Appendable which outputs from controller
   */

  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model, Appendable ap) {
    this.model = model;
    this.ap = ap;
  }

  /**
   * represents 1 argument constructor for the view.
   *
   * @param model represents the model for the pryamid solitaire game
   */
  public PyramidSolitaireTextualView(PyramidSolitaireModel<?> model) {
    this.model = model;
  }

  // produces the toString() of the game
  @Override
  public String toString() {
    return model.toString();
  }

  /**
   * Renders a model in some manner (e.g. as text, or as graphics, etc.).
   * @throws IOException if the rendering fails for some reason
   */
  @Override
  public void render() throws IOException {
    this.ap.append(this.toString());
  }
}

