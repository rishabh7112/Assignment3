package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.BasicPyramidSolitaire;
import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;

public class PyramidSolitaireCreator {

  public enum GameType {
    BASIC, RELAXED, MULTIPYRAMID
  }

  public static PyramidSolitaireModel<Card> create(GameType type) {
    if (type.equals(GameType.BASIC)) {
      return new BasicPyramidSolitaire();
    }
    if (type.equals(GameType.RELAXED)) {
      return new RelaxedPyramidSolitaireModel();
    }
    if (type.equals(GameType.MULTIPYRAMID)) {
      return new MultiPyramidSolitaireModel();
    }
    throw new IllegalArgumentException("invalid game type");
  }
}
