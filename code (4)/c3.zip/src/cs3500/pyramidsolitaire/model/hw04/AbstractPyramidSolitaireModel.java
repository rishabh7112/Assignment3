package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.Card;
import cs3500.pyramidsolitaire.model.hw02.PyramidSolitaireModel;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public abstract class AbstractPyramidSolitaireModel implements PyramidSolitaireModel<Card> {

  protected int numRows;
  protected int numDraw;
  protected List<Card> drawCards;
  protected ArrayList<ArrayList<Card>> pyramid;

  public AbstractPyramidSolitaireModel() {
    this.numRows = 0;
    this.numDraw = 0;
    this.drawCards = new ArrayList<Card>();
    this.pyramid = new ArrayList<ArrayList<Card>>();
  }



  @Override
  public List<Card> getDeck() {
    List<Card> cards = new ArrayList<>();
    for (Card.Rank r : Card.Rank.values()) {
      for (Card.Suit s : Card.Suit.values()) {
        cards.add(new Card(r, s));
      }
    }
    return cards;
  }

  @Override
  public void startGame(List <Card> deck, boolean shuffle, int numRows, int numDraw)
      throws IllegalArgumentException {

    //Check deck is not null
    if (deck == null) {
      throw new IllegalArgumentException("Deck can't be null");
    }
    //Check deck is valid
    HashSet<Card> unique = new HashSet<Card>(deck);
    if (unique.size() != 52) {
      throw new IllegalArgumentException("Deck is not valid");
    }
    //Check int parameters to be valid
    if (numDraw < 0 || numRows <= 0) {
      throw new IllegalArgumentException("Num rows and num draw have to be positive");
    }
    //Check for a valid game inputs
    if ((numRows * (numRows + 1)) / 2 + numDraw > 52) {
      throw new IllegalArgumentException("Game can't be initialized with given parameters");
    }
    //Once all checks are done, start filling up the pyramid
    deck = new ArrayList<Card>(deck);
    this.numRows = numRows;
    this.numDraw = numDraw;
    //Check if shuffle is needed to start
    if (shuffle) {
      Random r = new Random();
      for (int n = 1; n < 1000; n++) {
        int i = r.nextInt(deck.size());
        int j = r.nextInt(deck.size());
        //Swap values on indices
        Card temp = deck.get(i);
        deck.set(i, deck.get(j));
        deck.set(j, temp);
      }
    }
    //Deal cards into pyramid
    pyramid = new ArrayList<ArrayList<Card>>();
    for (int i = 0; i < numRows; i++) {
      ArrayList<Card> row = new ArrayList<Card>();
      pyramid.add(row);
      for (int j = 0; j <= i; j++) {

        Card c = deck.remove(0);
        row.add(c);

      }
      //Add remaining cards into draw deck
      drawCards = new ArrayList<Card>(deck);
    }
  }

  @Override
  public void remove(int row1, int card1, int row2, int card2)
      throws IllegalArgumentException, IllegalStateException {
    //Check state of game
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    //Check for valid removal
    boolean valid = false;
    if (row1 >= 0 && row1 < numRows && card1 >= 0 && card1 < pyramid.get(row1).size()
        && row2 >= 0 && row2 < numRows && card2 >= 0 && card2 < pyramid.get(row2).size()) {
      //Check front cards to be removed
      //Check card 1 valid
      if (((row1 == numRows - 1) || (pyramid.get(row1 + 1).get(card1) == null
          && pyramid.get(row1 + 1).get(card1 + 1) == null)) &&
          ((row2 == numRows - 1) || (pyramid.get(row2 + 1).get(card2) == null
              && pyramid.get(row2 + 1).get(card2 + 1) == null))) {
        valid = true;
      }
    }
    if (valid && pyramid.get(row1).get(card1) != null &&
        pyramid.get(row2).get(card2) != null &&
        pyramid.get(row1).get(card1).getRank().value() +
            pyramid.get(row2).get(card2).getRank().value() == 13) {
      pyramid.get(row1).set(card1, null);
      pyramid.get(row2).set(card2, null);
    } else {
      throw new IllegalArgumentException("Removal for requested cards is not possible");
    }
  }

  @Override
  public void remove(int row, int card) throws IllegalArgumentException, IllegalStateException {
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    //Check for valid removal
    boolean valid = false;
    if (row >= 0 && row < numRows && card >= 0 && card < pyramid.get(row).size()) {
      //Check front cards to be removed
      //Check card 1 valid
      if (((row == numRows - 1) || (pyramid.get(row + 1).get(card) == null
          && pyramid.get(row + 1).get(card + 1) == null))) {
        valid = true;
      }
    }
    if (valid && pyramid.get(row).get(card) != null &&
        pyramid.get(row).get(card).getRank().value() == 13) {
      pyramid.get(row).set(card, null);
    } else {
      throw new IllegalArgumentException("Removal for requested card is not possible");
    }
  }

  @Override
  public void removeUsingDraw(int drawIndex, int row, int card)
      throws IllegalArgumentException, IllegalStateException {
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    //Check for valid removal
    boolean valid = false;
    if (row >= 0 && row < numRows && card >= 0 && card < pyramid.get(row).size()) {
      //Check front cards to be removed
      //Check card 1 valid
      if (((row == numRows - 1) || (pyramid.get(row + 1).get(card) == null
          && pyramid.get(row + 1).get(card + 1) == null))) {
        valid = true;
      }
    }
    if (valid && pyramid.get(row).get(card) != null && drawIndex >= 0
        && drawIndex < numDraw && drawIndex < drawCards.size()
        && drawCards.get(drawIndex).getRank().value() +
        pyramid.get(row).get(card).getRank().value() == 13) {
      pyramid.get(row).set(card, null);
      drawCards.remove(drawIndex);
    } else {
      throw new IllegalArgumentException("Removal for requested card is not possible");
    }

  }

  @Override
  public void discardDraw(int drawIndex) throws IllegalArgumentException, IllegalStateException {
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    //Check for valid removal
    if (drawIndex >= 0 && drawIndex < numDraw && drawIndex < drawCards.size()) {
      drawCards.remove(drawIndex);
    } else {
      throw new IllegalArgumentException("Removal for requested card is not possible");
    }
  }

  @Override
  public int getNumRows() {
    if (pyramid.size() == 0) {
      return -1;
    }
    return numRows;
  }

  @Override
  public int getNumDraw() {
    if (pyramid.size() == 0) {
      return -1;
    }
    return numDraw;
  }

  @Override
  public int getRowWidth(int row) {
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    if (row >= 0 && row < numRows) {
      return pyramid.get(row).size();
    } else {
      throw new IllegalArgumentException("Invalid row requested");
    }
  }

  @Override
  public boolean isGameOver() throws IllegalStateException {
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    if (getScore() == 0) {
      //Player won!
      return true;
    }
    if (numDraw < drawCards.size()) {
      return false;
    }
    List<Card> availableCards = getAvailableCards();
    for (int i = 0; i < availableCards.size(); i++) {
      for (int j = i + 1; j < availableCards.size(); j++) {
        if (availableCards.get(i).getRank().value() +
            availableCards.get(j).getRank().value() == 13) {
          return false;
        } else if (availableCards.get(i).getRank().value() == 13) {
          return false;
        }
      }
    }
    return true;
  }

  protected List<Card> getAvailableCards() {
    List<Card> cards = new ArrayList<Card>(drawCards);
    for (int i = 0; i < numRows; i++) {
      for (int j = numRows - 1; j >= 0 && j >= i; j--) {
        if (pyramid.get(j).get(i) != null && ((j == numRows - 1) ||
            (pyramid.get(j + 1).get(i) == null
                && pyramid.get(j + 1).get(i + 1) == null))) {
          cards.add(pyramid.get(j).get(i));
          break;
        }
      }
    }
    return cards;
  }

  @Override
  public int getScore() throws IllegalStateException {
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    int score = 0;
    for (int i = 0; i < numRows; i++) {
      for (int j = 0; j <= i; j++) {
        if (pyramid.get(i).get(j) != null) {
          score += pyramid.get(i).get(j).getRank().value();
        }
      }
    }
    return score;
  }

  @Override
  public Card getCardAt(int row, int card) throws IllegalStateException {
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    if (row >= 0 && row < numRows && card >= 0 && card < pyramid.get(row).size()) {
      return pyramid.get(row).get(card);
    } else {
      throw new IllegalArgumentException("Invalid card requested " + row + " " + card);
    }
  }

  @Override
  public List getDrawCards() throws IllegalStateException {
    ArrayList<Card> visible = new ArrayList<Card>();
    for (int i = 0; i < numDraw && i < drawCards.size(); i++) {
      visible.add(drawCards.get(i));
    }
    return visible;
  }
}

