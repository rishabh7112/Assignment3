import static org.junit.Assert.*;

import cs3500.pyramidsolitaire.model.hw04.MultiPyramidSolitaireModel;
import cs3500.pyramidsolitaire.view.PyramidSolitaireTextualView;
import cs3500.pyramidsolitaire.view.PyramidSolitaireView;
import java.io.IOException;
import org.junit.Test;

public class MultiPyramidSolitaireModelTest {

  @Test
  public void getDeck() throws IOException {
    MultiPyramidSolitaireModel m1 = new MultiPyramidSolitaireModel();
    StringBuffer b = new StringBuffer();
    m1.startGame(m1.getDeck(), true, 7 , 3);
    PyramidSolitaireView p1 = new PyramidSolitaireTextualView(m1, b);
    p1.render();
    assertEquals("", b.toString());
  }

  @Test
  public void startGame() {
  }

  @Test
  public void getRowWidth() {
  }
}