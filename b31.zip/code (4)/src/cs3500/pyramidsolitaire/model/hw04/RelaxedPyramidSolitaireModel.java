package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.Card;
import java.util.List;

public class RelaxedPyramidSolitaireModel extends AbstractPyramidSolitaireModel {

  @Override
  public void remove(int row1, int card1, int row2, int card2)
      throws IllegalArgumentException, IllegalStateException {
    //Check state of game
    //Check state of game
    if (pyramid.size() == 0) {
      throw new IllegalStateException("Game has not started yet");
    }
    //Check for valid removal
    boolean valid = false;
    if (row1 >= 0 && row1 < numRows && card1 >= 0 && card1 <= row1
        && row2 >= 0 && row2 < numRows && card2 >= 0 && card2 <= row2) {
      //Check front cards to be removed
      //Check card 1 valid
      if ((((row1 == numRows - 1) || (pyramid.get(row1 + 1).get(card1) == null
          && pyramid.get(row1 + 1).get(card1 + 1) == null)) &&
          ((row2 == numRows - 1) || (pyramid.get(row2 + 1).get(card2) == null
              && pyramid.get(row2 + 1).get(card2 + 1) == null)))) {
        valid = true;
      } else if (((pyramid.get(row1 + 1).get(card1) != null &&
          pyramid.get(row1 + 1).get(card1).getRank().value() +
              pyramid.get(row1).get(card1).getRank().value() == 13) || (
          pyramid.get(row1 + 1).get(card1 + 1) != null &&
              pyramid.get(row1 + 1).get(card1 + 1).getRank().value() +
                  pyramid.get(row1).get(card1).getRank().value() == 13)) || (
          (pyramid.get(row2 + 1).get(card2) != null &&
              pyramid.get(row2 + 1).get(card1).getRank().value() +
                  pyramid.get(row2).get(card1).getRank().value() == 13) || (
              pyramid.get(row2 + 1).get(card2 + 1) != null &&
                  pyramid.get(row2 + 1).get(card1 + 1).getRank().value() +
                      pyramid.get(row2).get(card2).getRank().value() == 13))) {
        valid = true;
      }

    }
    if (valid && pyramid.get(row1).get(card1) != null &&
        pyramid.get(row2).get(card2) != null &&
        pyramid.get(row1).get(card1).getRank().value() +
            pyramid.get(row2).get(card2).getRank().value() == 13) {
      pyramid.get(row1).set(card1, null);
      pyramid.get(row2).set(card2, null);
    }
  }

  @Override
  public boolean isGameOver() throws IllegalStateException {

    return false;
  }
}