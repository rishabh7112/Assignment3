package cs3500.pyramidsolitaire.model.hw04;

import cs3500.pyramidsolitaire.model.hw02.Card;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class MultiPyramidSolitaireModel extends AbstractPyramidSolitaireModel {

  @Override
  public List<Card> getDeck() {
    List<Card> cards = new ArrayList<>();
    for (Card.Rank r : Card.Rank.values()) {
      for (Card.Suit s : Card.Suit.values()) {
        cards.add(new Card(r, s));
      }
    }
    return cards;
  }

  @Override
  public void startGame(List deck, boolean shuffle, int numRows, int numDraw)
      throws IllegalArgumentException {

  }

  @Override
  public int getRowWidth(int row) {
    return 0;
  }
}
