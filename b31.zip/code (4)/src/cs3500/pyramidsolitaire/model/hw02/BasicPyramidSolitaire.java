package cs3500.pyramidsolitaire.model.hw02;

import cs3500.pyramidsolitaire.model.hw04.AbstractPyramidSolitaireModel;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

/**
 * represents a model for the pyramid solitaire game.
 */
public class BasicPyramidSolitaire extends AbstractPyramidSolitaireModel {


}